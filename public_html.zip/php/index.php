<?php
// Incluir o arquivo de configuração que contém as credenciais do banco de dados
include 'config.php'; // Certifique-se de que 'config.php' contém as credenciais corretas

// Criar a conexão com o banco de dados
$conn = new mysqli($db_host, $db_user, $db_password, $db_name);

// Verificar a conexão
if ($conn->connect_error) {
    die("Conexão falhou: " . $conn->connect_error);
}

// Preparar a consulta para evitar SQL Injection
$stmt = $conn->prepare("SELECT * FROM perfis_instagram WHERE username = ?");
$stmt->bind_param("s", $username_instagram); // "s" indica que o parâmetro é uma string

// Receber o nome de usuário do Instagram enviado via POST
$username_instagram = $_POST['username'];

// Executar a consulta
$stmt->execute();

// Obter o resultado
$result = $stmt->get_result();
if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    
    // Retornar os dados como JSON para o frontend
    echo json_encode([
        'success' => true,
        'nome_completo' => $row['nome_completo'],
        'foto_perfil' => $row['foto_perfil'],
        'story_views' => explode(',', $row['story_views']),  // Transformar os dados em array
        'profile_visits' => explode(',', $row['profile_visits'])  // Transformar os dados em array
    ]);
} else {
    // Se o perfil não for encontrado
    echo json_encode(['success' => false]);
}

// Fechar a consulta e a conexão
$stmt->close();
$conn->close();
?>
